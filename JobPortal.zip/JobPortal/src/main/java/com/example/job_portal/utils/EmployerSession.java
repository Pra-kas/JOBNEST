package com.example.job_portal.utils;

public class EmployerSession {
    public static String username;

    public static String userType;
}
