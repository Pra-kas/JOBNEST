package com.example.job_portal.utils;

public class UserSession {
    public static String username;

    public static String userType;
}
